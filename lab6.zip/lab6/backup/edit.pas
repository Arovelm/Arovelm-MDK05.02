unit Edit;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, Buttons;

type

  { TfEdit }

  TfEdit = class(TForm)
    Label1: TLabel;
    eName: TEdit;
    Label2: TLabel;
    eTelephone: TEdit;
    Label3: TLabel;
    CBNote: TComboBox;
    bSave: TBitBtn;
    bCancel: TBitBtn;
    procedure FormCreate(Sender: TObject);
    procedure FormShow(Sender: TObject);
  private

  public

  end;

var
  fEdit: TfEdit;

implementation

{$R *.lfm}

procedure TfEdit.FormShow(Sender: TObject);
begin
  eName.SetFocus;
end;

procedure TfEdit.FormCreate(Sender: TObject);
begin

end;

end.
