﻿type 
  ItemRecord = record
    ItemName: string;
    ItemCost: real;
    MinAge: string;
  end;

begin
  var stock: array[1..3] of ItemRecord;
  
  with stock[1] do
  begin
    ItemName := 'Набор Lego City';
    ItemCost := 5499.99;
    MinAge := '6+';
  end;
  
  with stock[2] do
  begin
    ItemName := 'Кукла Barbie';
    ItemCost := 2899.50;
    MinAge := '3+';
  end;
  
  with stock[3] do
  begin
    ItemName := 'Мягкая игрушка Дракон';
    ItemCost := 1799.00;
    MinAge := '0+';
  end;
  
  for var idx: integer := 1 to 3 do 
  begin
    with stock[idx] do
      writeln(ItemName:25, ' | ', ItemCost:8:2, ' | ', MinAge);
  end;
end.