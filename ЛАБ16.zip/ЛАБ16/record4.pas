﻿type 
  ToyItem = record
    Name: string;
    Price: real;
    Age: string;
  end;

begin
  var f: text;
  var toy: ToyItem;
  var toys: array[1..3] of ToyItem;
  
  with toys[1] do
  begin
    Name := 'Плюшевый мишка';
    Price := 1299.50;
    Age := '0+';
  end;
  
  with toys[2] do
  begin
    Name := 'Конструктор Лего';
    Price := 5499.99;
    Age := '6+';
  end;
  
  with toys[3] do
  begin
    Name := 'Настольная игра';
    Price := 2499.00;
    Age := '12+';
  end;
  
  assign(f, 'toys.txt');
  rewrite(f);
  for var i: integer := 1 to 3 do
    writeln(f, toys[i].Name, '|', toys[i].Price, '|', toys[i].Age);
  close(f);
  
  reset(f);
  while not eof(f) do
  begin
    var line: string;
    var parts: array of string;
    var name, age: string;
    var price: real;
    
    readln(f, line);
    parts := line.Split('|');
    name := parts[0];
    price := real.Parse(parts[1]);
    age := parts[2];
    
    writeln(name:20, ' | ', price:8:2, ' | ', age);
  end;
  close(f);
end.