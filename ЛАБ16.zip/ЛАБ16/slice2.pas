﻿begin
  var length := ReadInteger('Длина массива: ');
  var numbers := ReadArrInteger('Массив: ', length);
  print('Результат (элементы на четных позициях): ');
  numbers[1::2].println();
end.