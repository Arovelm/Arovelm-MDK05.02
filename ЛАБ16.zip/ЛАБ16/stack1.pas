﻿type 
  PNode = ^Node;
  Node = record
    data: integer;
    next: PNode;
  end;
  
var
  stack: PNode;
  inputFile, outputFile: text;
  value: integer;
  i: integer;
  
procedure Push(var head: PNode; item: integer);
var newNode: PNode;
begin
  New(newNode);
  newNode^.data := item;
  newNode^.next := head;
  head := newNode;
end;

function Pop(var head: PNode): integer;
var temp: PNode;
begin
  if head <> nil then
  begin
    Result := head^.data;
    temp := head;
    head := head^.next;
    Dispose(temp);
  end;
end;

begin
  assign(inputFile, 'input.txt');
  rewrite(inputFile);
  for i := 1 to 10 do
    writeln(inputFile, i);
  close(inputFile);

  stack := nil;
  assign(inputFile, 'input.txt');
  reset(inputFile);
  
  while not eof(inputFile) do
  begin
    readln(inputFile, value); 
    Push(stack, value);
  end;
  close(inputFile);
  
  assign(outputFile, 'output.txt');
  rewrite(outputFile);
  
  while stack <> nil do
  begin
    value := Pop(stack);
    write(outputFile, value, ' ');
  end;
  close(outputFile);
end.