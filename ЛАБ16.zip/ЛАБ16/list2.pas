﻿begin
  var length := ReadInteger('Длина списка: ');
  var numbers := lst(arrRandomInteger(length, 1, 100));
  
  print('Список: ');
  numbers.println;
  numbers.RemoveAt(l.IndexMax);
    
  print('Результат: ');
  numbers.println;
end.