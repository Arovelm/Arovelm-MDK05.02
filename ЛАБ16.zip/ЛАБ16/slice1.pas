﻿begin
  var length := ReadInteger('Длина массива: ');
  var numbers := ReadArrInteger('Массив: ', length);
  print('Результат: ');
  numbers[::-1].println();
end.