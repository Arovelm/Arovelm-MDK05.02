﻿begin
  var length := ReadInteger('Длина массива: ');
  var numbers := ReadArrInteger('Массив: ', length);
  print('Минимальный элемент на четных позициях: ');
  numbers[1::2].min().println();
end.