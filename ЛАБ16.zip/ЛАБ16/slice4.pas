﻿begin
  var length := ReadInteger('Длина массива: ');
  var numbers := ReadArrInteger('Массив: ', length);
  
  var maxIndex := numbers.IndexMax();
  numbers := numbers[:maxIndex] + numbers[maxIndex + 1:];
  
  print('Результат (массив без максимального элемента): ');
  numbers.println();
end.