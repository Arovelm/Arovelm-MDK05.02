﻿type TCharSet = set of Char;

const
  letters: TCharSet = ['a'..'z', 'A'..'Z', '_'];
  digits: TCharSet = ['0'..'9'];

var
  inputString: string;
  index: byte;
  isValid: boolean := true;
  
begin
  read(inputString);
  
  if inputString[1] not in letters then
    isValid := false;
  
  if isValid then
    for index := 2 to length(inputString) do
      if inputString[index] not in letters + digits then
      begin
        isValid := false;
        break;
      end;
      
  print(isValid);
end.