﻿type
  PNode = ^Node;
  Node = record
    value: integer;
    next: PNode;
  end;
  
var
  head, tail, current: PNode;
  i, minValue, maxValue: integer;
  
begin
  Randomize;
  head := nil;
  tail := nil;
  
  for i := 1 to 15 do
  begin
    new(current);
    current^.value := Random(100) + 1;
    current^.next := nil;
    
    if head = nil then
      head := current
    else
      tail^.next := current;
    tail := current;
  end;
  
  print('Список:');
  current := head;
  while current <> nil do
  begin
    print(current^.value);
    current := current^.next;
  end;
  println();
  
  if head <> nil then
  begin
    minValue := head^.value;
    maxValue := head^.value;
    current := head^.next;
    
    while current <> nil do
    begin
      if current^.value < minValue then 
        minValue := current^.value;
      if current^.value > maxValue then 
        maxValue := current^.value;
      current := current^.next;
    end;
  end;
  
  println('Максимум:', maxValue);
  print('Минимум:', minValue);
end.