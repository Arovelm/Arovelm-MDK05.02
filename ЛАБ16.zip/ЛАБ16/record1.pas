﻿type anketa = record
  fio: string;
  birth: string;
  kurs: 1..5;
end;

begin
  var student: anketa;
  
  student.fio := 'Velkov Roman Yureuich';
  student.birth := '09.10.2008';
  student.kurs := 2;
  
  print(student.fio, ' | ', student.birth, ' | ', student.kurs);
end.