﻿begin
  var length := ReadInteger('Длина массива: ');
  var numbers := ReadArrInteger('Массив: ', length);
  
  var newNumber := ReadInteger('Введите число для вставки: ');
  
  var minIndex := numbers.IndexMin();
  numbers := numbers[:minIndex] + Arr(newNumber) + numbers[minIndex:];
  
  print('Результат (число вставлено перед минимальным элементом): ');
  numbers.Println();
end.