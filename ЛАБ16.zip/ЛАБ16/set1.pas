﻿var
  ones, twosThreesFours, specialTeens: set of byte;
  number: integer;

begin
  ones := [1];
  twosThreesFours := [2, 3, 4];
  specialTeens := [0, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14];
  
  read(number);
  
  if (number mod 10 in specialTeens) or (number mod 100 in specialTeens) then
    print(number, 'лет')
  else if number mod 10 in ones then
    print(number, 'год')
  else
    print(number, 'года');
end.