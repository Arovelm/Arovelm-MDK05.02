﻿type
  PNode = ^Node;
  Node = record
    value: integer;
    next: PNode;
  end;
  
var
  head, tail, current: PNode;
  i: integer;
  
begin
  head := nil;
  tail := nil;
  
  for i := 1 to 10 do
  begin
    new(current);
    current^.value := i;
    current^.next := nil;
    
    if head = nil then
      head := current
    else
      tail^.next := current;
    tail := current;
  end;
  
  print('Список:');
  current := head;
  while current <> nil do
  begin
    print(current^.value);
    current := current^.next;
  end;
  println();
  
  print('Четные элементы:');
  current := head;
  while current <> nil do
  begin
    if current^.value mod 2 = 0 then
      print(current^.value);
    current := current^.next;
  end;
end.