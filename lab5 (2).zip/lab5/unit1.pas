﻿Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, Clipbrd;

type

  { TfMain }

  TfMain = class(TForm)
    lblList: TLabel;
    ListBoxIdeas: TListBox;
    lblNew: TLabel;
    lblTitle: TLabel;
    EditTitle: TEdit;
    lblCategory: TLabel;
    ComboCategory: TComboBox;
    lblText: TLabel;
    MemoIdea: TMemo;
    btnAdd: TButton;
    btnDelete: TButton;
    btnSave: TButton;
    btnLoad: TButton;
    btnClear: TButton;
    btnCopy: TButton;

    procedure btnAddClick(Sender: TObject);
    procedure btnDeleteClick(Sender: TObject);
    procedure btnSaveClick(Sender: TObject);
    procedure btnLoadClick(Sender: TObject);
    procedure btnClearClick(Sender: TObject);
    procedure btnCopyClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure ListBoxIdeasClick(Sender: TObject);

  private
    FDataFile: string;
    procedure SaveToFile;
    procedure LoadFromFile;
    procedure ClearFields;
    procedure AddIdeaToList;

  public

  end;

var
  fMain: TfMain;

implementation

{$R *.lfm}

procedure TfMain.FormCreate(Sender: TObject);
begin
  Caption := 'Копилка идей';
  Position := poScreenCenter;
  BorderStyle := bsSingle;
  Width := 710;
  Height := 550;

  ListBoxIdeas.Font.Size := 11;

  ComboCategory.Items.Clear;
  ComboCategory.Items.Add('Идея');
  ComboCategory.Items.Add('План');
  ComboCategory.Items.Add('Проект');
  ComboCategory.Items.Add('Задача');
  ComboCategory.Items.Add('Мечта');
  ComboCategory.ItemIndex := 0;

  MemoIdea.ScrollBars := ssVertical;
  MemoIdea.WordWrap := True;

  FDataFile := 'Ideas.txt';

  LoadFromFile;
end;
procedure TfMain.AddIdeaToList;
var
  IdeaText: string;
begin
  if EditTitle.Text = '' then
  begin
    ShowMessage('Введите заголовок идеи!');
    Exit;
  end;

  if MemoIdea.Text = '' then
  begin
    ShowMessage('Введите текст идеи!');
    Exit;
  end;

  IdeaText := '[' + ComboCategory.Text + '] ' + EditTitle.Text;

  ListBoxIdeas.Items.Add(IdeaText);

  SaveToFile;

  ClearFields;

  ShowMessage('Идея добавлена!');
end;
procedure TfMain.ClearFields;
begin
  EditTitle.Text := '';
  MemoIdea.Text := '';
  ComboCategory.ItemIndex := 0;
  EditTitle.SetFocus;
end;
procedure TfMain.SaveToFile;
begin
  ListBoxIdeas.Items.SaveToFile(FDataFile);
end;
procedure TfMain.LoadFromFile;
begin
  if FileExists(FDataFile) then
    ListBoxIdeas.Items.LoadFromFile(FDataFile);
end;
procedure TfMain.btnAddClick(Sender: TObject);
begin
  AddIdeaToList;
end;
procedure TfMain.btnDeleteClick(Sender: TObject);
begin
  if ListBoxIdeas.ItemIndex = -1 then
  begin
    ShowMessage('Выберите идею для удаления!');
    Exit;
  end;

  if MessageDlg('Подтверждение', 'Удалить выбранную идею?',
    mtConfirmation, [mbYes, mbNo], 0) = mrYes then
  begin
    ListBoxIdeas.Items.Delete(ListBoxIdeas.ItemIndex);
    SaveToFile;
    ShowMessage('Идея удалена!');
  end;
end;
procedure TfMain.btnSaveClick(Sender: TObject);
begin
  SaveToFile;
  ShowMessage('Идеи сохранены в файл: ' + FDataFile);
end;
procedure TfMain.btnLoadClick(Sender: TObject);
begin
  LoadFromFile;
  ShowMessage('Идеи загружены из файла!');
end;
procedure TfMain.btnClearClick(Sender: TObject);
begin
  ClearFields;
end;
procedure TfMain.btnCopyClick(Sender: TObject);
var
  FullText: string;
begin
  if ListBoxIdeas.ItemIndex = -1 then
  begin
    ShowMessage('Выберите идею для копирования!');
    Exit;
  end;

  FullText := ListBoxIdeas.Items[ListBoxIdeas.ItemIndex] + #13#10 +
              '---' + #13#10 + MemoIdea.Text;
  Clipboard.AsText := FullText;
  ShowMessage('Идея скопирована в буфер обмена!');
end;
procedure TfMain.ListBoxIdeasClick(Sender: TObject);
var
  SelectedIdea: string;
begin
  if ListBoxIdeas.ItemIndex >= 0 then
  begin
    SelectedIdea := ListBoxIdeas.Items[ListBoxIdeas.ItemIndex];
    Caption := 'Копилка идей - выбрано: ' + SelectedIdea;
  end;
end;

end.
