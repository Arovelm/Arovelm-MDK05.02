﻿unit Unit1;

{$mode delphi} // Режим Delphi для работы LowerCase с кириллицей

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, Menus, ExtCtrls,
  StdCtrls, Grids;

type
  // Структура записи для файла базы данных
  TStudent = record
    FIO: string[100];
    Group: string[15];
    Subject: string[50];
    Mark: Integer;
    Date: string[12];
  end;

  { TForm1 }

  TForm1 = class(TForm)
    EditFIO, EditGroup, EditSubject, EditMark, EditDate: TEdit;
    Label1, Label2, Label3, Label4, Label5: TLabel; // Добавлены все TLabel!
    MainMenu1: TMainMenu;
    MenuFile, MenuNew, MenuOpen, MenuSave, MenuSaveAs, MenuClose, MenuExit: TMenuItem;
    MenuRecord, MenuAdd, MenuEdit, MenuDelete, MenuSort, MenuSortAsc, MenuSortDesc, MenuSearch, MenuClear: TMenuItem;
    OpenDialog1: TOpenDialog; SaveDialog1: TSaveDialog;
    PanelInput: TPanel; // Добавлена TPanel!
    StringGrid1: TStringGrid;
    procedure FormCreate(Sender: TObject);
    procedure MenuNewClick(Sender: TObject);
    procedure MenuOpenClick(Sender: TObject);
    procedure MenuSaveClick(Sender: TObject);
    procedure MenuSaveAsClick(Sender: TObject);
    procedure MenuCloseClick(Sender: TObject);
    procedure MenuExitClick(Sender: TObject);
    procedure MenuAddClick(Sender: TObject);
    procedure MenuEditClick(Sender: TObject);
    procedure MenuDeleteClick(Sender: TObject);
    procedure MenuSortAscClick(Sender: TObject);
    procedure MenuSortDescClick(Sender: TObject);
    procedure MenuSearchClick(Sender: TObject);
    procedure MenuClearClick(Sender: TObject);
    procedure StringGrid1SelectCell(Sender: TObject; aCol, aRow: Integer; var CanSelect: Boolean);
  private
    FileName: string;
    Records: array of TStudent;
    procedure UpdateGrid;
  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

procedure TForm1.FormCreate(Sender: TObject);
begin
  FileName := 'students.dat';
  StringGrid1.Cells[0, 0] := '№'; StringGrid1.Cells[1, 0] := 'ФИО';
  StringGrid1.Cells[2, 0] := 'Группа'; StringGrid1.Cells[3, 0] := 'Предмет';
  StringGrid1.Cells[4, 0] := 'Оценка'; StringGrid1.Cells[5, 0] := 'Дата сдачи';

  if FileExists(FileName) then MenuOpenClick(nil);
end;

procedure TForm1.UpdateGrid;
var i: Integer;
begin
  StringGrid1.RowCount := Length(Records) + 1;
  for i := 0 to High(Records) do
  begin
    StringGrid1.Cells[0, i + 1] := IntToStr(i + 1);
    StringGrid1.Cells[1, i + 1] := Records[i].FIO;
    StringGrid1.Cells[2, i + 1] := Records[i].Group;
    StringGrid1.Cells[3, i + 1] := Records[i].Subject;
    StringGrid1.Cells[4, i + 1] := IntToStr(Records[i].Mark);
    StringGrid1.Cells[5, i + 1] := Records[i].Date;
  end;
end;

// Открытие файла базы данных
procedure TForm1.MenuOpenClick(Sender: TObject);
var F: file of TStudent; R: TStudent;
begin
  if (Sender <> nil) and not OpenDialog1.Execute then Exit;
  if Sender <> nil then FileName := OpenDialog1.FileName;
  if not FileExists(FileName) then Exit;

  AssignFile(F, FileName); Reset(F); SetLength(Records, 0);
  while not Eof(F) do begin
    Read(F, R); SetLength(Records, Length(Records) + 1); Records[High(Records)] := R;
  end;
  CloseFile(F); UpdateGrid;
end;

// Безопасное сохранение
procedure TForm1.MenuSaveClick(Sender: TObject);
var F: file of TStudent; i: Integer;
begin
  if FileName = '' then begin MenuSaveAsClick(Sender); Exit; end;
  try
    AssignFile(F, FileName); Rewrite(F);
    for i := 0 to High(Records) do Write(F, Records[i]);
    CloseFile(F);
    ShowMessage('База успешно сохранена!');
  except
    ShowMessage('Не удалось сохранить файл!');
  end;
end;

procedure TForm1.MenuSaveAsClick(Sender: TObject);
begin
  if SaveDialog1.Execute then begin FileName := SaveDialog1.FileName; MenuSaveClick(Sender); end;
end;

// Добавление студента
procedure TForm1.MenuAddClick(Sender: TObject);
var M: Integer;
begin
  if not TryStrToInt(EditMark.Text, M) then begin ShowMessage('Оценка должна быть числом!'); Exit; end;
  SetLength(Records, Length(Records) + 1);
  Records[High(Records)].FIO := EditFIO.Text;
  Records[High(Records)].Group := EditGroup.Text;
  Records[High(Records)].Subject := EditSubject.Text;
  Records[High(Records)].Mark := M;
  Records[High(Records)].Date := EditDate.Text;
  UpdateGrid; MenuClearClick(nil);
end;

// Редактирование записи
procedure TForm1.MenuEditClick(Sender: TObject);
var Idx, M: Integer;
begin
  Idx := StringGrid1.Row - 1;
  if (Idx < 0) or (Idx >= Length(Records)) then Exit;
  if not TryStrToInt(EditMark.Text, M) then begin ShowMessage('Оценка должна быть числом!'); Exit; end;

  Records[Idx].FIO := EditFIO.Text; Records[Idx].Group := EditGroup.Text;
  Records[Idx].Subject := EditSubject.Text; Records[Idx].Mark := M; Records[Idx].Date := EditDate.Text;
  UpdateGrid; MenuClearClick(nil);
end;

// Удаление записи
procedure TForm1.MenuDeleteClick(Sender: TObject);
var Idx, i: Integer;
begin
  Idx := StringGrid1.Row - 1;
  if (Idx < 0) or (Idx >= Length(Records)) then Exit;
  for i := Idx to Length(Records) - 2 do Records[i] := Records[i + 1];
  SetLength(Records, Length(Records) - 1); UpdateGrid;
end;

// Универсальная текстовая сортировка по столбцам
procedure TForm1.MenuSortAscClick(Sender: TObject);
begin
  StringGrid1.SortColRow(True, StringGrid1.Col);
end;

procedure TForm1.MenuSortDescClick(Sender: TObject);
begin
  StringGrid1.SortColRow(False, StringGrid1.Col);
end;

// Поиск по ФИО в любом регистре
procedure TForm1.MenuSearchClick(Sender: TObject);
var S: string; i: Integer;
begin
  S := InputBox('Поиск', 'Введите ФИО студента:', '');
  if Trim(S) = '' then Exit;

  for i := 0 to High(Records) do
    if Pos(LowerCase(S), LowerCase(Records[i].FIO)) > 0 then begin
      StringGrid1.Row := i + 1; Exit;
    end;
  ShowMessage('Студент не найден.');
end;

// Перенос выбранной строки в поля ввода
procedure TForm1.StringGrid1SelectCell(Sender: TObject; aCol, aRow: Integer; var CanSelect: Boolean);
var Idx: Integer;
begin
  Idx := aRow - 1;
  if (Idx >= 0) and (Idx < Length(Records)) then begin
    EditFIO.Text := Records[Idx].FIO; EditGroup.Text := Records[Idx].Group;
    EditSubject.Text := Records[Idx].Subject; EditMark.Text := IntToStr(Records[Idx].Mark);
    EditDate.Text := Records[Idx].Date;
  end;
end;

procedure TForm1.MenuClearClick(Sender: TObject);
begin
  EditFIO.Text:=''; EditGroup.Text:=''; EditSubject.Text:=''; EditMark.Text:=''; EditDate.Text:='';
end;

procedure TForm1.MenuNewClick(Sender: TObject); begin SetLength(Records, 0); UpdateGrid; end;
procedure TForm1.MenuCloseClick(Sender: TObject); begin MenuNewClick(nil); end;
procedure TForm1.MenuExitClick(Sender: TObject); begin Close; end;

end.
