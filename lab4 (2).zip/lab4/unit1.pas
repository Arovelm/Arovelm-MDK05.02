unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, FileUtil, Forms, Controls, Graphics, Dialogs, Clipbrd, StdCtrls, Math;

type

  { TForm1 }

  TForm1 = class(TForm)
    But1: TButton;
    But10: TButton;
    But11: TButton;
    But12: TButton;
    But13: TButton;
    But14: TButton;
    But15: TButton;
    But16: TButton;
    But17: TButton;
    But18: TButton;
    But19: TButton;
    But2: TButton;
    But22: TButton;
    But3: TButton;
    But4: TButton;
    But5: TButton;
    But6: TButton;
    But7: TButton;
    But8: TButton;
    But9: TButton;
    But20: TButton;
    But21: TButton;
    Edit1: TEdit;

    procedure ClickBut(Sender: TObject);
    procedure ClickZnak(Sender: TObject);
    procedure But15Click(Sender: TObject);
    procedure But16Click(Sender: TObject);
    procedure But17Click(Sender: TObject);
    procedure But18Click(Sender: TObject);
    procedure But20Click(Sender: TObject);
    procedure But21Click(Sender: TObject);
    procedure But22Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);

  private
    a, b, c: real;
    znak: string;
    FWaitingForNumber: boolean;

    procedure AddComma;
    procedure ClearAll;
    procedure Calculate;
    function HasComma: boolean;

  public

  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

procedure TForm1.FormCreate(Sender: TObject);
begin
  Caption := 'Калькулятор';
  Position := poScreenCenter;
  BorderStyle := bsSingle;
  BorderIcons := [biSystemMenu, biMinimize];
  Color := $00F0F0F0;

  Edit1.ReadOnly := True;
  Edit1.Alignment := taRightJustify;
  Edit1.Font.Size := 28;
  Edit1.Font.Name := 'Segoe UI';
  Edit1.Color := clWhite;

  But1.Caption := '1'; But2.Caption := '2'; But3.Caption := '3';
  But4.Caption := '4'; But5.Caption := '5'; But6.Caption := '6';
  But7.Caption := '7'; But8.Caption := '8'; But9.Caption := '9';
  But10.Caption := '0';
  But11.Caption := '+'; But12.Caption := '-';
  But13.Caption := '*'; But14.Caption := '/';
  But15.Caption := '√'; But16.Caption := 'x²';
  But17.Caption := '='; But18.Caption := 'CE';
  But19.Caption := ',';
  But20.Caption := '←';
  But21.Caption := 'C'; But22.Caption := 'Kop';

  a := 0; b := 0; c := 0; znak := ''; FWaitingForNumber := False;
end;


function TForm1.HasComma: boolean;
begin
  Result := Pos(',', Edit1.Text) > 0;
end;

procedure TForm1.AddComma;
begin
  if HasComma then
    Exit;

  if FWaitingForNumber then
  begin
    Edit1.Text := '0,';
    FWaitingForNumber := False;
    Exit;
  end;

  if Edit1.Text = '' then
    Edit1.Text := '0,'
  else
    Edit1.Text := Edit1.Text + ',';
end;

procedure TForm1.ClickBut(Sender: TObject);
var
  btnCaption: string;
begin
  btnCaption := (Sender as TButton).Caption;

  if btnCaption = ',' then
  begin
    AddComma;
    Exit;
  end;

  if FWaitingForNumber then
  begin
    Edit1.Text := '';
    FWaitingForNumber := False;
  end;

  if (Edit1.Text = '0') then
    Edit1.Text := btnCaption
  else
    Edit1.Text := Edit1.Text + btnCaption;
end;

procedure TForm1.ClickZnak(Sender: TObject);
var
  newZnak: string;
  tempText: string;
begin
  newZnak := (Sender as TButton).Caption;

  if Edit1.Text = '' then
    Exit;

  if znak <> '' then
    Calculate;

  tempText := StringReplace(Edit1.Text, ',', '.', [rfReplaceAll]);

  try
    a := StrToFloat(tempText);
  except
    Edit1.Text := 'Ошибка';
    Exit;
  end;

  znak := newZnak;
  FWaitingForNumber := True;
  Edit1.Text := '';
end;

procedure TForm1.Calculate;
var
  tempText: string;
begin
  if Edit1.Text = '' then
    Exit;

  if znak = '' then
    Exit;
  tempText := StringReplace(Edit1.Text, ',', '.', [rfReplaceAll]);

  try
    b := StrToFloat(tempText);
  except
    Edit1.Text := 'Ошибка';
    znak := '';
    FWaitingForNumber := False;
    Exit;
  end;

  if (znak = '/') and (b = 0) then
  begin
    Edit1.Text := 'Ошибка: деление на 0';
    znak := '';
    FWaitingForNumber := False;
    Exit;
  end;

  case znak of
    '+': c := a + b;
    '-': c := a - b;
    '*': c := a * b;
    '/': c := a / b;
  end;

  Edit1.Text := StringReplace(FloatToStr(c), '.', ',', [rfReplaceAll]);
  znak := '';
  FWaitingForNumber := False;
end;

procedure TForm1.But17Click(Sender: TObject);
begin
  if znak <> '' then
    Calculate;
end;

procedure TForm1.But18Click(Sender: TObject);
begin
  Edit1.Text := '';
  FWaitingForNumber := False;
end;

procedure TForm1.But21Click(Sender: TObject);
begin
  Edit1.Text := '';
  a := 0; b := 0; c := 0;
  znak := '';
  FWaitingForNumber := False;
end;

procedure TForm1.But20Click(Sender: TObject);
begin
  if Length(Edit1.Text) > 0 then
    Edit1.Text := Copy(Edit1.Text, 1, Length(Edit1.Text) - 1);

  if Edit1.Text = '' then
    Edit1.Text := '0';
end;

procedure TForm1.But15Click(Sender: TObject);
var
  tempText: string;
begin
  if Edit1.Text = '' then Exit;

  tempText := StringReplace(Edit1.Text, ',', '.', [rfReplaceAll]);

  try
    a := StrToFloat(tempText);
  except
    Edit1.Text := 'Ошибка';
    Exit;
  end;

  if a < 0 then
    Edit1.Text := 'Ошибка: отриц. число'
  else
    Edit1.Text := StringReplace(FloatToStr(Sqrt(a)), '.', ',', [rfReplaceAll]);

  a := 0;
  znak := '';
  FWaitingForNumber := False;
end;

procedure TForm1.But16Click(Sender: TObject);
var
  tempText: string;
begin
  if Edit1.Text = '' then Exit;

  tempText := StringReplace(Edit1.Text, ',', '.', [rfReplaceAll]);

  try
    a := StrToFloat(tempText);
  except
    Edit1.Text := 'Ошибка';
    Exit;
  end;

  Edit1.Text := StringReplace(FloatToStr(Sqr(a)), '.', ',', [rfReplaceAll]);
  a := 0;
  znak := '';
  FWaitingForNumber := False;
end;

procedure TForm1.But22Click(Sender: TObject);
begin
  if Edit1.Text <> '' then
    Clipboard.AsText := Edit1.Text;
end;

procedure TForm1.ClearAll;
begin
  Edit1.Text := '';
  a := 0; b := 0; c := 0;
  znak := '';
  FWaitingForNumber := False;
end;

end.

