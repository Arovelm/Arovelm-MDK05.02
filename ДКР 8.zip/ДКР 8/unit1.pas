﻿unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls,
  StdCtrls;

type
  TForm1 = class(TForm)
    cbFigure: TComboBox;
    lblA, lblB, lblH: TLabel;
    edtA, edtB, edtH: TEdit;
    btnCalculate: TButton;
    lblResult: TLabel;
    procedure FormCreate(Sender: TObject);
    procedure cbFigureChange(Sender: TObject);
    procedure btnCalculateClick(Sender: TObject);
  private
    procedure UpdateControls;
  public
  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

procedure TForm1.FormCreate(Sender: TObject);
begin
  Caption := 'Калькулятор площади фигур - ЛР №8';
  Position := poScreenCenter;
  BorderStyle := bsDialog;
  Width := 460;
  Height := 420;

  // Выбор фигуры
  cbFigure.Caption := 'Выберите фигуру';
  cbFigure.Items.Add('Прямоугольник');
  cbFigure.Items.Add('Треугольник');
  cbFigure.Items.Add('Круг');
  cbFigure.Items.Add('Трапеция');
  cbFigure.Items.Add('Параллелограмм');
  cbFigure.ItemIndex := 0;
  cbFigure.Style := csDropDownList;
  cbFigure.OnChange := @cbFigureChange;

  lblA.Caption := 'Сторона A:';
  lblB.Caption := 'Сторона B:';
  lblH.Caption := 'Высота:';

  btnCalculate.Caption := 'Рассчитать площадь';
  btnCalculate.Font.Style := [fsBold];
  btnCalculate.Height := 45;

  lblResult.Alignment := taCenter;
  lblResult.Font.Size := 14;
  lblResult.Font.Color := clNavy;
  lblResult.AutoSize := False;  
  UpdateControls;
end;

procedure TForm1.UpdateControls;
begin
  lblA.Visible := True;
  edtA.Visible := True;
  lblB.Visible := True;
  edtB.Visible := True;
  lblH.Visible := False;
  edtH.Visible := False;
  
  edtA.Text := '';
  edtB.Text := '';
  edtH.Text := '';
  
  case cbFigure.ItemIndex of
    0: // Прямоугольник
      begin
        lblA.Caption := 'Длина (a):';
        lblB.Caption := 'Ширина (b):';
      end;
    1: // Треугольник
      begin
        lblA.Caption := 'Основание (a):';
        lblB.Caption := 'Сторона b (необяз.):';
        lblH.Visible := True;
        edtH.Visible := True;
        lblH.Caption := 'Высота (h):';
      end;
    2: // Круг
      begin
        lblA.Caption := 'Радиус (R):';
        lblB.Visible := False;
        edtB.Visible := False;
      end;
    3: // Трапеция
      begin
        lblA.Caption := 'Основание (a):';
        lblB.Caption := 'Основание (b):';
        lblH.Visible := True;
        edtH.Visible := True;
        lblH.Caption := 'Высота (h):';
      end;
    4: // Параллелограмм
      begin
        lblA.Caption := 'Основание (a):';
        lblB.Caption := 'Сторона b (необяз.):';
        lblH.Visible := True;
        edtH.Visible := True;
        lblH.Caption := 'Высота (h):';
      end;
  end;
end;

procedure TForm1.cbFigureChange(Sender: TObject);
begin
  UpdateControls;
  lblResult.Caption := '';
end;

procedure TForm1.btnCalculateClick(Sender: TObject);
var
  a, b, h, Area: Double;
  Ok: Boolean;
begin
  lblResult.Caption := '';
  Ok := True;

  a := StrToFloatDef(edtA.Text, -1);
  if a <= 0 then Ok := False;

  case cbFigure.ItemIndex of
    0: // Прямоугольник S = a * b
      begin
        b := StrToFloatDef(edtB.Text, -1);
        if b <= 0 then Ok := False;
        if Ok then Area := a * b;
      end;

    1: // Треугольник S = (a * h) / 2
      begin
        h := StrToFloatDef(edtH.Text, -1);
        if h <= 0 then Ok := False;
        if Ok then Area := (a * h) / 2;
      end;

    2: // Круг S = π * R²
      begin
        if Ok then Area := Pi * a * a;
      end;

    3: // Трапеция S = ((a + b) * h) / 2
      begin
        b := StrToFloatDef(edtB.Text, -1);
        h := StrToFloatDef(edtH.Text, -1);
        if (b <= 0) or (h <= 0) then Ok := False;
        if Ok then Area := ((a + b) * h) / 2;
      end;

    4: // Параллелограмм S = a * h
      begin
        h := StrToFloatDef(edtH.Text, -1);
        if h <= 0 then Ok := False;
        if Ok then Area := a * h;
      end;
    
    else
      Ok := False;
  end;

  if not Ok then
    MessageDlg('Ошибка ввода!', 'Введите положительные числа для всех обязательных полей.', mtError, [mbOK], 0)
  else
    lblResult.Caption := 'Площадь = ' + FormatFloat('0.00', Area);
end;

end.