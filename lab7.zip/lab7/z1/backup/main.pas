unit Main;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs;

type
  Tfmain = class(TForm)
  private

  public

  end;

var
  fmain: Tfmain;

implementation

{$R *.lfm}

end.

