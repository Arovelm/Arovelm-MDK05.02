unit Main;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls;

type
  TfMain = class(TForm)
    EditInput: TEdit;
    btnWrite: TButton;
    btnRead: TButton;
    MemoDisplay: TMemo;
    procedure btnWriteClick(Sender: TObject);
    procedure btnReadClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private

  public

  end;

var
  fMain: TfMain;

implementation

{$R *.lfm}

procedure TfMain.FormCreate(Sender: TObject);
begin
  Caption := 'Работа с текстовым файлом';
  EditInput.Text := '';
  MemoDisplay.Clear;
end;

// Запись в текстовый файл
procedure TfMain.btnWriteClick(Sender: TObject);
var
  tf: TextFile;
  s: String;
begin
  if EditInput.Text = '' then
  begin
    ShowMessage('Введите текст!');
    Exit;
  end;

  s := EditInput.Text;

  try
    AssignFile(tf, 'mytext.txt');

    if not FileExists('mytext.txt') then
      Rewrite(tf)
    else
      Append(tf);

    Writeln(tf, s);
    EditInput.Text := '';

  finally
    CloseFile(tf);
  end;

  ShowMessage('Строка добавлена в файл!');
end;

// Чтение из текстового файла
procedure TfMain.btnReadClick(Sender: TObject);
var
  tf: TextFile;
  s: String;
begin
  if not FileExists('mytext.txt') then
  begin
    ShowMessage('Файл не существует! Сначала добавьте данные.');
    Exit;
  end;

  MemoDisplay.Clear;

  try
    AssignFile(tf, 'mytext.txt');
    Reset(tf);

    while not Eof(tf) do
    begin
      Readln(tf, s);
      MemoDisplay.Lines.Add(s);
    end;

  finally
    CloseFile(tf);
  end;
end;

end.
