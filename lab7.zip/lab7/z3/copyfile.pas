﻿unit CopyFile;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, FileUtil, EditBtn, LCLType;

type
  TfMain = class(TForm)
    Label1: TLabel;
    FNE: TFileNameEdit;
    Label2: TLabel;
    DE: TDirectoryEdit;
    btnCopy: TButton;
    procedure btnCopyClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    
  public
    
  end;

var
  fMain: TfMain;

implementation

{$R *.lfm}

procedure TfMain.FormCreate(Sender: TObject);
begin
  Caption := 'Копирование файла';
  Width := 450;
  Height := 250;
  Position := poScreenCenter;
  BorderStyle := bsDialog;
  
  FNE.Text := '';
  DE.Text := '';
end;

// Копирование файла
procedure TfMain.btnCopyClick(Sender: TObject);
var
  fIn, fOut: File;
  NumRead, NumWritten: Word;
  Buf: array[1..2048] of byte;
  SourceFile, DestFile: string;
begin
  // Проверка: выбран ли файл
  if FNE.Text = '' then
  begin
    ShowMessage('Внимание! Требуется указать или выбрать копируемый файл.');
    FNE.SetFocus;
    Exit;
  end;
  
  // Проверка: выбрана ли папка
  if DE.Text = '' then
  begin
    ShowMessage('Внимание! Требуется указать или выбрать папку для копии.');
    DE.SetFocus;
    Exit;
  end;
  
  // Формируем пути к файлам
  SourceFile := FNE.FileName;
  DestFile := DE.Directory + '\' + ExtractFileName(FNE.FileName);
  
  // Проверка: существует ли исходный файл
  if not FileExists(SourceFile) then
  begin
    ShowMessage('Исходный файл не существует!');
    Exit;
  end;
  
  // Копирование
  try
    AssignFile(fIn, SourceFile);
    AssignFile(fOut, DestFile);
    
    Reset(fIn, 1);
    Rewrite(fOut, 1);
    
    Screen.Cursor := crHourGlass;
    
    // Инициализация переменных
    NumRead := 0;
    NumWritten := 0;
    
    repeat
      BlockRead(fIn, Buf, SizeOf(Buf), NumRead);
      BlockWrite(fOut, Buf, NumRead, NumWritten);
    until (NumRead = 0) or (NumWritten <> NumRead);
    
    ShowMessage('Копирование завершено!' + #13#10 +
                'Файл скопирован в: ' + DestFile);
    
  finally
    CloseFile(fIn);
    CloseFile(fOut);
    Screen.Cursor := crDefault;
  end;
end;

end.