﻿unit TypedFile;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls;

type
  TfMain = class(TForm)
    ListBoxNumbers: TListBox;
    btnCreate: TButton;
    btnRead: TButton;
    procedure btnCreateClick(Sender: TObject);
    procedure btnReadClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    
  public
    
  end;

var
  fMain: TfMain;

implementation

{$R *.lfm}

procedure TfMain.FormCreate(Sender: TObject);
begin
  Caption := 'Типизированный файл';
  Width := 350;
  Height := 300;
  Position := poScreenCenter;
  ListBoxNumbers.Clear;
end;

procedure TfMain.btnCreateClick(Sender: TObject);
var
  f: File of integer;
  i: integer;
begin
  try
    AssignFile(f, 'mytypefile.dat');
    Rewrite(f);
    
    Randomize;
    for i := 1 to 10 do
      Write(f, Random(1000));
    
    ShowMessage('Файл сформирован! Создано 10 случайных чисел.');
    
  finally
    CloseFile(f);
  end;
end;

procedure TfMain.btnReadClick(Sender: TObject);
var
  f: File of integer;
  k: integer;
begin
  if not FileExists('mytypefile.dat') then
  begin
    ShowMessage('Файл не существует! Сначала сформируйте файл.');
    Exit;
  end;
  
  ListBoxNumbers.Clear;
  
  try
    AssignFile(f, 'mytypefile.dat');
    Reset(f);
    
    while not Eof(f) do
    begin
      Read(f, k);
      ListBoxNumbers.Items.Add(IntToStr(k));
    end;
    
    ShowMessage('Данные успешно загружены!');
    
  finally
    CloseFile(f);
  end;
end;

end.

